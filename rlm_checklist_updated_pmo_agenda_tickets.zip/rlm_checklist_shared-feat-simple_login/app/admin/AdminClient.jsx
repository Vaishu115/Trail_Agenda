"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

export default function AdminClient() {
  const [pending, setPending] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busyCode, setBusyCode] = useState("");
  const [error, setError] = useState("");

  async function load() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/pending-employees");
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || "Failed to load pending employees");
      setPending(data.pending);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load pending employees");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    Promise.resolve().then(() => load());
  }, []);

  async function act(code, action) {
    setBusyCode(code);
    try {
      const res = await fetch("/api/approve-employee", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ employeeCode: code, action }),
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || "Action failed");
      setPending((prev) => prev.filter((p) => p.employee_code !== code));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Action failed");
    } finally {
      setBusyCode("");
    }
  }

  return (
    <div className="admin-wrap">
      <div className="admin-header">
        <div>
          <div className="landing-badge landing-badge-alt">Team Lead</div>
          <h1 className="admin-title">Pending Verifications</h1>
          <p className="admin-subtitle">Approve or reject new employee registration requests.</p>
        </div>
        <Link href="/login" className="landing-link">Back to login</Link>
      </div>

      {error ? <p className="auth-error" style={{ marginBottom: 16 }}>{error}</p> : null}

      {loading ? (
        <div className="admin-empty">Loading…</div>
      ) : pending.length === 0 ? (
        <div className="admin-empty">No pending registrations right now.</div>
      ) : (
        <div className="admin-list">
          {pending.map((p) => (
            <div key={p.employee_code} className="admin-row">
              <div className="admin-row-info">
                <div className="admin-row-name">{p.name}</div>
                <div className="admin-row-meta">
                  Code: <strong>{p.employee_code}</strong>
                  {p.created_at ? <> · Requested {p.created_at}</> : null}
                </div>
              </div>
              <div className="admin-row-actions">
                <button
                  className="admin-btn admin-btn-approve"
                  disabled={busyCode === p.employee_code}
                  onClick={() => act(p.employee_code, "approve")}
                >
                  Approve
                </button>
                <button
                  className="admin-btn admin-btn-reject"
                  disabled={busyCode === p.employee_code}
                  onClick={() => act(p.employee_code, "reject")}
                >
                  Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
