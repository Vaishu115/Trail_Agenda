import AdminClient from "./AdminClient";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Team Lead Approvals · Trial SOP Checklist",
};

export default function AdminPage() {
  return <AdminClient />;
}
