import { NextResponse } from "next/server";
import { getDb } from "../../../lib/db";

export async function POST(request) {
  try {
    const { employeeCode, action } = await request.json();

    if (!employeeCode || typeof employeeCode !== "string") {
      return NextResponse.json({ ok: false, error: "Employee code is required" }, { status: 400 });
    }
    if (action !== "approve" && action !== "reject") {
      return NextResponse.json({ ok: false, error: "action must be 'approve' or 'reject'" }, { status: 400 });
    }

    const code = employeeCode.trim().toUpperCase();
    const db = getDb();

    if (action === "approve") {
      const result = db.prepare("UPDATE employees SET is_active = 1 WHERE employee_code = ?").run(code);
      if (result.changes === 0) {
        return NextResponse.json({ ok: false, error: "Employee code not found" }, { status: 404 });
      }
    } else {
      const result = db.prepare("DELETE FROM employees WHERE employee_code = ? AND is_active = 0").run(code);
      if (result.changes === 0) {
        return NextResponse.json({ ok: false, error: "Pending employee code not found" }, { status: 404 });
      }
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Employee approval error:", error);
    return NextResponse.json({ ok: false, error: "Server error" }, { status: 500 });
  }
}
