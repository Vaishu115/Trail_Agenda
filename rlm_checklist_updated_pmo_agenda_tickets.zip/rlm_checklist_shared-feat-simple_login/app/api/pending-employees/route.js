import { NextResponse } from "next/server";
import { getDb } from "../../../lib/db";

export async function GET() {
  try {
    const db = getDb();
    const pending = db
      .prepare(
        "SELECT employee_code, name, created_at FROM employees WHERE is_active = 0 ORDER BY created_at DESC",
      )
      .all();
    return NextResponse.json({ ok: true, pending });
  } catch (error) {
    console.error("Pending employees fetch error:", error);
    return NextResponse.json({ ok: false, error: "Server error" }, { status: 500 });
  }
}
