import { NextResponse } from "next/server";
import { getDb } from "../../../lib/db";

export async function POST(request) {
  try {
    const { employeeCode, name } = await request.json();

    if (!employeeCode || typeof employeeCode !== "string" || !employeeCode.trim()) {
      return NextResponse.json({ ok: false, error: "Employee code is required" }, { status: 400 });
    }
    if (!name || typeof name !== "string" || !name.trim()) {
      return NextResponse.json({ ok: false, error: "Name is required" }, { status: 400 });
    }

    const code = employeeCode.trim().toUpperCase();
    const cleanName = name.trim();

    const db = getDb();
    const existing = db.prepare("SELECT employee_code, is_active FROM employees WHERE employee_code = ?").get(code);

    if (existing) {
      if (existing.is_active === 1) {
        return NextResponse.json(
          { ok: false, error: "This employee code is already active. Try logging in instead." },
          { status: 409 },
        );
      }
      return NextResponse.json(
        { ok: false, error: "A registration for this employee code is already pending verification." },
        { status: 409 },
      );
    }

    db.prepare(
      "INSERT INTO employees (employee_code, name, is_active) VALUES (?, ?, 0)",
    ).run(code, cleanName);

    return NextResponse.json({ ok: true, employee: { code, name: cleanName } });
  } catch (error) {
    console.error("Employee registration error:", error);
    return NextResponse.json({ ok: false, error: "Server error" }, { status: 500 });
  }
}
