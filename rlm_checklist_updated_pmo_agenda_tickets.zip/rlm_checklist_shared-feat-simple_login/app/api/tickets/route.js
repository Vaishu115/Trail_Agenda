import { NextResponse } from "next/server";
import { sendTicketEmail } from "../../../lib/mailer";

export const runtime = "nodejs";

export async function POST(request) {
  try {
    const ticket = await request.json();
    if (!ticket?.ticketId || !ticket?.raisedBy || !ticket?.title) {
      return NextResponse.json({ ok: false, error: "Ticket data is incomplete." }, { status: 400 });
    }
    const result = await sendTicketEmail({ ticket });
    if (!result.ok) return NextResponse.json({ ok: false, error: result.error }, { status: 502 });
    return NextResponse.json({ ok: true, to: result.to });
  } catch (error) {
    console.error("Ticket submission error:", error);
    return NextResponse.json({ ok: false, error: "Could not process ticket." }, { status: 500 });
  }
}
