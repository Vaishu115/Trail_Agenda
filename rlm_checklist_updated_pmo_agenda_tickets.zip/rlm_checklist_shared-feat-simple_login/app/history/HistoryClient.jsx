"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../components/AuthProvider";
import { listTrials, loadTrial } from "../../lib/checklistStorage";

function csvValue(v) {
  return `"${String(v ?? "").replace(/"/g, '""')}"`;
}

function formatIso(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleString();
}

export default function HistoryClient() {
  const router = useRouter();
  const { employee, loading } = useAuth();
  const [trials, setTrials] = useState([]);
  const [search, setSearch] = useState("");
  const [sortNewest, setSortNewest] = useState(true);

  useEffect(() => {
    if (loading) return;
    if (!employee) {
      router.replace("/login?next=/history");
      return;
    }

    const metas = listTrials();
    const enriched = metas.map((meta) => {
      const data = loadTrial(meta.trialId) || {};
      return { ...meta, ...data, answers: data.answers || {} };
    });
    setTrials(enriched);
  }, [loading, employee, router]);

  const filteredTrials = useMemo(() => {
    const q = search.trim().toLowerCase();
    const filtered = trials.filter((t) => {
      const answers = t.answers || {};
      const agenda = `${answers["1"] || ""} ${answers["3"] || ""} ${answers["6"] || ""}`;
      const trialInfo = `${answers["7"] || ""} ${answers["10"] || ""} ${answers["11"] || ""} ${answers["15"] || ""}`;
      const searchString = `${t.title || ""} ${t.customTrialId || ""} ${t.trialId || ""} ${agenda} ${trialInfo}`.toLowerCase();
      return !q || searchString.includes(q);
    });

    return filtered.sort((a, b) => {
      const ad = new Date(a.answers?.["2"] || a.createdAt || 0).getTime();
      const bd = new Date(b.answers?.["2"] || b.createdAt || 0).getTime();
      return sortNewest ? bd - ad : ad - bd;
    });
  }, [trials, search, sortNewest]);

  function exportExcel() {
    const rows = [
      ["Trial", "Trial ID", "Agenda / Objective", "Trial Date", "Location", "Type", "Block/PTW", "Status", "Created At", "Updated At"],
      ...filteredTrials.map((t) => [
        t.title || "Untitled trial",
        t.customTrialId || t.trialId || "",
        t.answers?.["1"] || "",
        t.answers?.["2"] || "",
        t.answers?.["3"] || t.answers?.["11"] || "",
        t.answers?.["7"] || "",
        t.answers?.["8"] || "",
        t.submitted ? "Submitted" : "Draft",
        formatIso(t.createdAt),
        formatIso(t.updatedAt),
      ]),
    ];
    const csv = rows.map((r) => r.map(csvValue).join(",")).join("\n");
    const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `trial-history-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (loading || !employee) return null;

  return (
    <div style={{ padding: "40px", maxWidth: "1200px", margin: "0 auto", fontFamily: "var(--font-ui), sans-serif", minHeight: "100vh" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "16px", marginBottom: "28px", flexWrap: "wrap" }}>
        <button onClick={() => router.push("/form")} style={{ padding: "10px 16px", borderRadius: "8px", border: "1px solid var(--border)", background: "white", cursor: "pointer", fontWeight: "bold" }}>
          ← Back to Form
        </button>
        <h1 style={{ fontSize: "28px", color: "var(--accent)", margin: 0 }}>Trial History</h1>
        <button onClick={exportExcel} style={{ marginLeft: "auto", padding: "10px 16px", borderRadius: "8px", border: "1px solid var(--accent)", background: "var(--accent)", color: "white", cursor: "pointer", fontWeight: "bold" }}>
          Export Excel
        </button>
      </div>

      <div style={{ display: "flex", gap: "12px", marginBottom: "24px", flexWrap: "wrap" }}>
        <input
          type="text"
          placeholder="Search all trials by date, type, location, ID or agenda..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ flex: 1, minWidth: "280px", padding: "14px 20px", borderRadius: "12px", border: "1px solid var(--border)", fontSize: "16px", background: "white", boxShadow: "var(--shadow)" }}
        />
        <button
          onClick={() => setSortNewest((v) => !v)}
          style={{ padding: "12px 16px", borderRadius: "10px", border: "1px solid var(--border)", background: "white", cursor: "pointer", fontWeight: "700" }}
        >
          Sort by date: {sortNewest ? "Newest first" : "Oldest first"}
        </button>
      </div>

      <div style={{ marginBottom: "14px", color: "var(--text-sub)", fontSize: "14px" }}>
        Showing {filteredTrials.length} of {trials.length} trials
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
        {filteredTrials.length === 0 ? (
          <div style={{ padding: "40px", textAlign: "center", color: "var(--text-sub)", background: "white", borderRadius: "12px", border: "1px solid var(--border)" }}>
            No trials found.
          </div>
        ) : filteredTrials.map((t) => {
          const a = t.answers || {};
          const trialDate = a["2"] || a["9"] || "";
          const location = a["3"] || a["11"] || "—";
          const type = a["7"] || "—";
          return (
            <div key={t.trialId} style={{ background: "white", borderRadius: "16px", border: "1px solid var(--border)", padding: "24px", boxShadow: "var(--shadow)", display: "flex", justifyContent: "space-between", alignItems: "center", gap: "20px", flexWrap: "wrap" }}>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ fontSize: "18px", fontWeight: "900", color: "var(--accent)" }}>{t.title || "Untitled trial"}</div>
                <div style={{ display: "flex", gap: "16px", color: "var(--text-sub)", fontSize: "14px", flexWrap: "wrap", marginTop: "8px" }}>
                  <span><strong>Date:</strong> {trialDate || "—"}</span>
                  <span><strong>Type:</strong> {type}</span>
                  <span><strong>Location:</strong> {location}</span>
                  <span><strong>Status:</strong> {t.submitted ? "Submitted" : "Draft"}</span>
                </div>
                <div style={{ fontSize: "13px", color: "var(--text-light)", marginTop: "8px" }}>
                  <strong>Agenda:</strong> {a["1"] || "—"}
                </div>
                <div style={{ fontSize: "12px", color: "var(--text-light)", marginTop: "8px" }}>
                  Trial ID: {t.customTrialId || t.trialId} · Created: {formatIso(t.createdAt)} · Updated: {formatIso(t.updatedAt)}
                </div>
              </div>
              <button
                onClick={() => router.push(`/form?version=${encodeURIComponent(t.version || "Trolly")}&trialId=${encodeURIComponent(t.trialId)}`)}
                style={{ padding: "10px 16px", borderRadius: "10px", border: "1px solid var(--accent)", background: "var(--accent)", color: "white", fontWeight: "bold", cursor: "pointer" }}
              >
                Open Trial
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
