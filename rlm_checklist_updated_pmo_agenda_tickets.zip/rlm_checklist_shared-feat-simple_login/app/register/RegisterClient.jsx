"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";

const TEAM_LEAD_EMAIL = process.env.NEXT_PUBLIC_TEAM_LEAD_EMAIL || "vaishnavi.kulkarni@ericrobotics.com";

function buildMailto({ code, name }) {
  const subject = `New employee verification needed: ${name} (${code})`;
  const body =
    `Hi Team Lead,\n\n` +
    `A new employee has requested access to the Trial SOP Checklist app and needs verification:\n\n` +
    `  Employee Code: ${code}\n` +
    `  Name: ${name}\n\n` +
    `Please confirm this is a valid employee, then approve the request in the admin panel:\n` +
    `${typeof window !== "undefined" ? window.location.origin : ""}/admin\n\n` +
    `Thanks!`;
  return `mailto:${TEAM_LEAD_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

export default function RegisterClient() {
  const router = useRouter();
  const [employeeCode, setEmployeeCode] = useState("");
  const [name, setName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [registered, setRegistered] = useState(null); // { code, name }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!employeeCode.trim() || !name.trim()) {
      setError("Please enter both your employee code and name.");
      return;
    }
    setError("");
    setSubmitting(true);
    try {
      const res = await fetch("/api/register-employee", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ employeeCode: employeeCode.trim(), name: name.trim() }),
      });
      const data = await res.json();
      if (!data.ok) {
        throw new Error(data.error || "Registration failed. Please try again.");
      }
      setRegistered(data.employee);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Registration failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="landing">
      <div className="landing-bg" aria-hidden="true" />
      <div className="landing-grid landing-grid-single">
        <section className="landing-card">
          <div className="landing-badge landing-badge-alt">New Employee</div>
          <h1 className="landing-title" style={{ fontSize: "clamp(28px, 4vw, 40px)" }}>
            Register for access
          </h1>
          <p className="landing-subtitle">RailwayMitra · POC2</p>
          <p className="landing-desc">
            Enter your details below. Your request will be sent to your team lead for verification
            before you can sign in.
          </p>

          <div className="landing-authbox" role="region" aria-label="Employee registration">
            {registered ? (
              <div className="reg-success">
                <div className="reg-success-icon" aria-hidden="true">✓</div>
                <h2 className="reg-success-title">Request submitted</h2>
                <p className="reg-success-text">
                  <strong>{registered.name}</strong> ({registered.code}) has been added as{" "}
                  <em>pending verification</em>. You&apos;ll be able to sign in once your team lead
                  approves the request.
                </p>
                <a
                  className="auth-btn auth-btn-continue"
                  href={buildMailto(registered)}
                  style={{ marginTop: 16 }}
                >
                  <span className="auth-btn-text">Notify team lead by email</span>
                </a>
                <p className="reg-hint">
                  This opens your email app with the details pre-filled — sent to{" "}
                  <strong>{TEAM_LEAD_EMAIL}</strong>.
                </p>
                <Link href="/login" className="landing-link" style={{ marginTop: 18, display: "inline-block" }}>
                  Back to login
                </Link>
              </div>
            ) : (
              <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                <input
                  type="text"
                  placeholder="Employee Code"
                  className="q-input"
                  value={employeeCode}
                  onChange={(e) => setEmployeeCode(e.target.value)}
                  disabled={submitting}
                  autoFocus
                  style={{ width: "100%", boxSizing: "border-box", textTransform: "uppercase" }}
                />
                <input
                  type="text"
                  placeholder="Full Name"
                  className="q-input"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  disabled={submitting}
                  style={{ width: "100%", boxSizing: "border-box" }}
                />
                <button
                  className="auth-btn"
                  type="submit"
                  disabled={submitting}
                  style={{ backgroundColor: "#f4c430", color: "#2a2002", border: "none", justifyContent: "center" }}
                >
                  <span className="auth-btn-text">{submitting ? "Submitting…" : "Request Access"}</span>
                </button>
                {error ? <p className="auth-error">{error}</p> : null}
                <button
                  type="button"
                  className="landing-link"
                  style={{ textAlign: "center", marginTop: 4 }}
                  onClick={() => router.push("/login")}
                >
                  Already registered? Sign in
                </button>
              </form>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}
