"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../components/AuthProvider";

const STORAGE_KEY = "rlm_demo_support_tickets_v1";

export default function TicketsClient() {
  const router = useRouter();
  const { employee, loading } = useAuth();
  const [tickets, setTickets] = useState(() => {
    if (typeof window === "undefined") return [];
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (!stored) return [];
      const parsed = JSON.parse(stored);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (loading) return;
    if (!employee) {
      router.replace("/login?next=/tickets");
      return;
    }
  }, [loading, employee, router]);

  // Pick up tickets raised in another tab/window while this page is open.
  useEffect(() => {
    function refresh() {
      try {
        const stored = window.localStorage.getItem(STORAGE_KEY);
        const parsed = stored ? JSON.parse(stored) : [];
        setTickets(Array.isArray(parsed) ? parsed : []);
      } catch {
        // ignore malformed storage
      }
    }
    window.addEventListener("storage", refresh);
    window.addEventListener("focus", refresh);
    return () => {
      window.removeEventListener("storage", refresh);
      window.removeEventListener("focus", refresh);
    };
  }, []);

  const filteredTickets = tickets.filter((t) => {
    const searchString = `${t.ticketId || ""} ${t.title || ""} ${t.issueType || ""} ${t.module || ""} ${t.description || ""} ${t.employee || ""}`.toLowerCase();
    return searchString.includes(search.toLowerCase());
  });

  function formatIso(iso) {
    if (!iso) return "";
    try {
      const d = new Date(iso);
      return d.toLocaleDateString() + " " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    } catch {
      return iso;
    }
  }

  function updateStatus(ticketId, status, resolvedBy = "") {
    const next = tickets.map((t) =>
      t.ticketId === ticketId
        ? { ...t, status, resolvedBy, resolvedAt: status === "Resolved" ? new Date().toISOString() : "" }
        : t
    );
    setTickets(next);
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch {}
  }

  function statusColor(status) {
    if (status === "Resolved") return { bg: "#e6f7ee", fg: "#0a7a42" };
    if (status === "In Progress") return { bg: "#fff4e0", fg: "#a15c00" };
    return { bg: "#fdecec", fg: "#b3261e" }; // Open / default
  }

  if (loading || !employee) return null;

  return (
    <div style={{ padding: "40px", maxWidth: "1200px", margin: "0 auto", fontFamily: "var(--font-ui), sans-serif", minHeight: "100vh" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "20px", marginBottom: "40px" }}>
        <button
          onClick={() => router.push("/form")}
          style={{ padding: "10px 16px", borderRadius: "8px", border: "1px solid var(--border)", background: "white", cursor: "pointer", fontWeight: "bold" }}
        >
          ← Back to Form
        </button>
        <h1 style={{ fontSize: "28px", color: "var(--accent)" }}>Support Tickets</h1>
      </div>

      <div style={{ marginBottom: "24px" }}>
        <input
          type="text"
          placeholder="Search by ticket ID, title, issue type, or module..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ width: "100%", padding: "14px 20px", borderRadius: "12px", border: "1px solid var(--border)", fontSize: "16px", background: "white", boxShadow: "var(--shadow)" }}
        />
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
        {filteredTickets.length === 0 ? (
          <div style={{ padding: "40px", textAlign: "center", color: "var(--text-sub)", background: "white", borderRadius: "12px", border: "1px solid var(--border)" }}>
            {tickets.length === 0 ? "No tickets raised yet on this device." : "No tickets found matching your search."}
          </div>
        ) : (
          filteredTickets.map((t) => {
            const colors = statusColor(t.status);
            return (
              <div key={t.ticketId} style={{ background: "white", borderRadius: "16px", border: "1px solid var(--border)", padding: "24px", boxShadow: "var(--shadow)", display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "16px", flexWrap: "wrap" }}>
                <div style={{ display: "flex", flexDirection: "column", gap: "8px", flex: 1, minWidth: "260px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap" }}>
                    <span style={{ fontSize: "18px", fontWeight: "900", color: "var(--accent)" }}>{t.title}</span>
                    <span style={{ fontSize: "12px", fontWeight: "700", color: colors.fg, background: colors.bg, padding: "4px 10px", borderRadius: "999px" }}>
                      {t.status || "Open"}
                    </span>
                  </div>
                  <div style={{ fontSize: "13px", color: "var(--text-light)" }}>{t.ticketId}</div>
                  <div style={{ display: "flex", gap: "16px", color: "var(--text-sub)", fontSize: "14px", flexWrap: "wrap" }}>
                    <span><strong>Type:</strong> {t.issueType || "—"}</span>
                    <span><strong>Module:</strong> {t.module || "—"}</span>
                    <span><strong>When it happened:</strong> {t.when || "—"}</span>
                  </div>
                  <div style={{ fontSize: "14px", color: "var(--text)", marginTop: "4px" }}>{t.description}</div>
                  <div style={{ fontSize: "12px", color: "var(--text-light)", marginTop: "8px" }}>
                    Raised by {t.employee || "Demo User"} &nbsp;|&nbsp; {formatIso(t.createdAt)}
                    {t.trialId ? <>&nbsp;|&nbsp; Trial: {t.trialId}</> : null}
                  </div>
                  {t.resolvedBy ? (
                    <div style={{ fontSize: "12px", color: "var(--text-sub)" }}>
                      Resolved by: <strong>{t.resolvedBy}</strong> · {formatIso(t.resolvedAt)}
                    </div>
                  ) : null}
                  <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginTop: "8px" }}>
                    <button onClick={() => updateStatus(t.ticketId, "Open")} style={{ padding: "7px 11px", borderRadius: "8px", border: "1px solid var(--border)", background: "white", cursor: "pointer", fontWeight: "700" }}>Open</button>
                    <button onClick={() => updateStatus(t.ticketId, "Resolved")} style={{ padding: "7px 11px", borderRadius: "8px", border: "1px solid #0a7a42", background: "#e6f7ee", color: "#0a7a42", cursor: "pointer", fontWeight: "700" }}>Resolved</button>
                    <button onClick={() => updateStatus(t.ticketId, "Resolved", employee?.name || "Team Lead")} style={{ padding: "7px 11px", borderRadius: "8px", border: "1px solid var(--accent)", background: "var(--accent)", color: "white", cursor: "pointer", fontWeight: "700" }}>Resolved by me</button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
